#=============================================================================================================
# Projet fonctionnel et complet mais dont l'amélioration nécessiterait une version du logiciel non limitante
#=============================================================================================================

@ Projet
	Projet_Micro INFO1 2018-2019

@ Créateurs
	Divi De Lacour
	Marc Vacquant
	Tony Chouteau

@ Nom
	Fluffitten's Adventure

@ Construction
	Voir : ./SchemaBloc.pdf
	
@ Fonctionnement
	Au lancement : Enfoncé KEY1 pour réinitialiser la mémoire
	Dans les menus : Ecran tactile pour naviguer
	Dans le jeu : Joystick pour se déplacer, KEY1 pour attaquer, KEY2 pour retourner au menu et sauvegarder
	
@ /!\ MONTAGE /!\
	Le programme a été fait pour un LCD monté côté CNA
	Un LCD monter coté CNB rendra l'affichage non conforme aux attentes