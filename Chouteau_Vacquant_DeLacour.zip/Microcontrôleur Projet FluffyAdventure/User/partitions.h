//partitions utilisables


//theme principal
tnote thprincipal[73]={{do3,40},{mi3,20},usil,{mi3,40},usil,{mi3,20},{re3,20},{mi3,20},{fa3,20},{sol3,40},{0,20},{sol3,40},{fa3,20},{mi3,40},{fa3,20},{mi3,40},{re3,20},{do3,60},{la2,60},{sol2,80},{0,20},
												{do3,40},{mi3,20},usil,{mi3,40},usil,{mi3,20},{re3,20},{mi3,20},{fa3,20},{sol3,40},{0,20},{sol3,40},{fa3,20},{mi3,40},{fa3,20},{mi3,40},{re3,20},{do3,100},
												{mi3,60},{sol3,60},{re3,60},{sol3,60},{fa3,40},{sol3,20},{fa3,40},{mi3,20},{sol3,60},{0,60},{mi3,60},{sol3,60},{re3,60},{sol3,60},{fa3,40},{sol3,20},{fa3,40},{mi3,20},{sol3,60},
												{fa3,40},{sol3,20},{mi3,40},{sol3,20},{do3,20},{re3,20},{mi3,20},usil,{mi3,40},{do3,20},{re3,40},{sol2,20},{do3,60},usil,
													finp};
